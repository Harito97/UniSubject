echo “Tuan 07: Cac toan tu trong lap trinh shell va Vong lap” > tailieu.txt
for ((i=1;i<=3;i++))
do cat tailieu.txt > tailieu$i.txt
done