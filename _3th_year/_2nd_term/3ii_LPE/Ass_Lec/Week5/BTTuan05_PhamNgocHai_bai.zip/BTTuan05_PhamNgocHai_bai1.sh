echo 'I am a student'
pwd
ls -a
date