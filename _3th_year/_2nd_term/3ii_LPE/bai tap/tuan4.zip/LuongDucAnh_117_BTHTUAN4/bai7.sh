for ((i=1;i<=4;i++))
do echo "Toi la sinh vien "$i > file_$i.txt
done 
