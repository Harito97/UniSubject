ls ~/Desktop
ls ~/Desktop | grep -E '*.sh'
