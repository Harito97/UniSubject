#include <omp.h>
#include <stdio.h>

// Dinh nghia kich thuoc mang
#define N 5
// Dinh nghia so luong thread su dung
#define T 5

/* Yeu Cau: Tinh tong 2 mang A va B va luu vao mang C
Input:
	A: Mang 1 chieu co N phan tu nguyen
	B: Mang 1 chieu co N phan tu nguyen
	C: Luu gia tri tong cua 2 mang A va B
*/
void getSumOfTwoArrays(int A[N], int B[N], int C[N]){
	int chunkSize = (int) N/T;
	// Lay so luong thread lon nhat la N, neu T > N
	int numOfThreads = T > N ? N : T;
	#pragma omp parallel num_threads(numOfThreads)
	{
		int i = omp_get_thread_num();
		int startIndex = i * chunkSize;
		int endIndex = i != T - 1 ? (i + 1) * chunkSize : N;
		for (int j = startIndex; j < endIndex; ++j){
			C[j] = A[j] + B[j];
		}
	}
}

// Xuat ra man hinh console
void printSumOfTwoArrays(int C[N]){
	for (int i = 0; i < N; i++){
		printf("%d ", C[i]);
	}
}

int main() {
	int A[N] = {1, 2, 3, 4, 5};
	int B[N] = {1, 2, 3, 4, 5};
	
	int C[N];
	getSumOfTwoArrays(A, B, C);
	
	printSumOfTwoArrays(C);
	
	return 0;
}