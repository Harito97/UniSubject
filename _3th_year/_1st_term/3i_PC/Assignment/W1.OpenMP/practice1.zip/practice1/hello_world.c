#include <omp.h>
#include <stdio.h>

int main() {

	#pragma omp parallel num_threads(5)
	{
		printf("Hello world, from thread number %d\n",omp_get_thread_num());
	}
}