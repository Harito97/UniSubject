#include <omp.h>
#include <stdio.h>

// Dinh nghia kich thuoc mang 2 chieu (ma tran vuong)
#define N 9

// Ham nhan tich chap theo vi tri hang i, cot j cua ma tran B
int filter(int A[N][N], int F[3][3], int i, int j){
	int sum = 0;
	for (int m = 0; m < 3; ++m){
		for (int n = 0; n < 3; ++n){
			sum += F[m][n] * A[i + m - 1][j + n - 1];
		}
	}
	return sum;
}

/* Yeu Cau: Nhan tich chap mang A voi ma tran loc F, luu vao mang B
Input:
	A: Mang hai chieu kich thuoc NxN
	F: Bo loc kich thuoc 3x3
	B: Mang A sau khi nhan tich chap voi bo loc F duoc luu vao mang B co kich thuoc NxN
*/
void matrixFilter(int A[N][N], int F[3][3], int B[N][N]){
	#pragma omp parallel num_threads(N - 2)
	{
		int thread_i = omp_get_thread_num();
		int i = thread_i + 1;
		for (int j = 1; j < N - 1; ++j){
			B[i][j] = filter(A, F, i, j);
		}
	}
}

// Ham xuat ket qua ra man hinh console
void printMatrixAfterFilter(int B[N][N]){
	for (int i = 0; i < N; ++i){
		for (int j = 0; j < N; ++j){
			printf("%d ", B[i][j]);
		}
		printf("\n");
	}
}


int main() {
	// Du lieu test
	int A[N][N] = 
	{
		{0, 0, 0, 0, 0, 0, 0, 0, 1},
		{0, 0, 0, 0, 0, 0, 0, 1, 1},
		{0, 0, 0, 0, 0, 0, 1, 1, 1},
		{0, 0, 0, 0, 0, 1, 1, 1, 1},
		{0, 0, 0, 0, 1, 1, 1, 1, 1},
		{0, 0, 0, 1, 1, 1, 1, 1, 1},
		{0, 0, 1, 1, 1, 1, 1, 1, 1},
		{0, 1, 1, 1, 1, 1, 1, 1, 1},
		{1, 1, 1, 1, 1, 1, 1, 1, 1},
	};
	int F[3][3] = 
	{
		{0, -1, 0},
		{-1, 4, -1},
		{0, -1, 0}
	};
	
	int B[N][N] = {0};
	matrixFilter(A, F, B);
	
	printMatrixAfterFilter(B);
	
	return 0;
}